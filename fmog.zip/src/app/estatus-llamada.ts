export interface EstatusLlamada {
}
