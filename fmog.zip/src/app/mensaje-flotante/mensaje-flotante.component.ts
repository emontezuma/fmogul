import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mensaje-flotante',
  templateUrl: './mensaje-flotante.component.html',
  styleUrls: ['./mensaje-flotante.component.css']
})
export class MensajeFlotanteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
