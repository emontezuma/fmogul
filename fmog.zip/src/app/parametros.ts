export interface Parametros {
    cliente: string,
    planta: string,
    serial: string,
    version: string,
    tiempo_reporte: number,
    tiempo_cierre_turno: number
}
